$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$scriptPath = Join-Path $PSScriptRoot 'ai_video_generator.py'
$python = Get-Command py.exe -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command python.exe -ErrorAction SilentlyContinue
}
if (-not $python) {
    Write-Host 'Python est introuvable. Installe Python 3.10 ou plus récent, puis réessaie.' -ForegroundColor Red
    Read-Host 'Appuie sur Entrée pour fermer'
    exit 1
}

Write-Host 'Générateur IA — Images et vidéos'
Write-Host '1. Créer une image'
Write-Host '2. Créer une vidéo'
$mode = Read-Host 'Choisis 1 ou 2'
if ($mode -notin @('1', '2')) {
    Write-Host 'Choix invalide.' -ForegroundColor Red
    Read-Host 'Appuie sur Entrée pour fermer'
    exit 1
}

$subject = Read-Host 'Décris ce que tu veux créer'
if ([string]::IsNullOrWhiteSpace($subject)) {
    Write-Host 'La description ne peut pas être vide.' -ForegroundColor Red
    Read-Host 'Appuie sur Entrée pour fermer'
    exit 1
}

Write-Host 'Styles : 1 = 3D, 2 = photo, 3 = illustration, 4 = cinéma'
$styleChoice = Read-Host 'Choisis un style (défaut 1)'
$styles = @{ '1' = '3d'; '2' = 'photo'; '3' = 'illustration'; '4' = 'cinematic' }
if ([string]::IsNullOrWhiteSpace($styleChoice)) {
    $styleChoice = '1'
}
if (-not $styles.ContainsKey($styleChoice)) {
    Write-Host 'Style invalide.' -ForegroundColor Red
    Read-Host 'Appuie sur Entrée pour fermer'
    exit 1
}

$outputDir = Join-Path $PSScriptRoot 'output'
if ($mode -eq '1') {
    $outputPath = Join-Path $outputDir 'image_ia.png'
    $arguments = @($scriptPath, $subject, '--image-only', '--visual-style', $styles[$styleChoice], '--out', $outputPath)
} else {
    $durationText = Read-Host 'Durée en secondes (défaut 60)'
    $duration = 60
    if (-not [string]::IsNullOrWhiteSpace($durationText) -and
        (-not [int]::TryParse($durationText, [ref]$duration) -or $duration -lt 5)) {
        Write-Host 'Saisis une durée d’au moins 5 secondes.' -ForegroundColor Red
        Read-Host 'Appuie sur Entrée pour fermer'
        exit 1
    }
    $outputPath = Join-Path $outputDir 'video_ia.mp4'
    $arguments = @($scriptPath, $subject, '--duration', [string]$duration, '--visual-style', $styles[$styleChoice], '--out', $outputPath)
}

Write-Host ''
& $python.Source @arguments
$exitCode = $LASTEXITCODE
if ($exitCode -eq 0) {
    Write-Host 'Terminé. Résultat dans le dossier output du générateur.' -ForegroundColor Green
} else {
    Write-Host "La génération a échoué (code $exitCode). Lis le message ci-dessus." -ForegroundColor Red
}
Read-Host 'Appuie sur Entrée pour fermer'
exit $exitCode
