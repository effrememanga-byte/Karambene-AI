#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI_VIDEO_GENERATOR v2.4 — Génération d'images autonome et diagnostic vidéo.

Pipeline : prompt → LLM (scènes) → TTS voix off → visuels (vidéo IA / Ken Burns /
stock) → assemblage FFmpeg (xfade + sous-titres + musique) → MP4.

Usage :
  python ai_video_generator.py --check --image-only
  python ai_video_generator.py "Une bouteille de jus de bissap en rendu 3D" --image-only --visual-style 3d --out output\\bissap.png
  python ai_video_generator.py "Un voyage sur Mars" --duration 60
  python ai_video_generator.py "L'histoire du café" --visual-style 3d --video-provider runway

Image : une clé Gemini est requise (saisie interactive ou GEMINI_API_KEY).
Vidéo : FFmpeg et les dépendances du fichier ai_video_generator_requirements.txt
sont requis. La vidéo IA native requiert aussi une clé Runway, Luma ou Replicate.
"""

import argparse, base64, importlib.util, json, os, shutil, subprocess, sys, time
from pathlib import Path

WORKDIR = Path("build")
OUTDIR  = Path("output")
REQUIREMENTS_PATH = Path(__file__).resolve().with_name("ai_video_generator_requirements.txt")


def check_ffmpeg():
    if os.name == "nt":
        try:
            import winreg
        except ImportError:
            winreg = None
        if winreg:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as env:
                    user_path, _ = winreg.QueryValueEx(env, "Path")
            except FileNotFoundError:
                user_path = ""
            if isinstance(user_path, str):
                current = {part.casefold() for part in os.environ.get("PATH", "").split(os.pathsep)}
                added = [part for part in user_path.split(os.pathsep)
                         if part and part.casefold() not in current]
                if added:
                    os.environ["PATH"] = os.pathsep.join(
                        added + [os.environ.get("PATH", "")]
                    )

    missing = [binary for binary in ("ffmpeg", "ffprobe") if not shutil.which(binary)]
    if missing:
        raise RuntimeError(
            "FFmpeg/FFprobe introuvable(s) dans le PATH : " + ", ".join(missing) +
            ". Installe FFmpeg puis ajoute son dossier bin au PATH."
        )


PROVIDER_KEYS = {
    "runway": "RUNWAY_API_KEY",
    "luma": "LUMA_API_KEY",
    "replicate": "REPLICATE_API_TOKEN",
}


def check_dependencies(video_provider: str = "none", image_only: bool = False) -> bool:
    if image_only:
        if os.getenv("GEMINI_API_KEY"):
            print("[OK] Mode image prêt; clé Gemini configurée.")
            return True
        print("[ERREUR] Clé GEMINI_API_KEY requise pour générer une image.")
        print("         Lance le script sans --no-config pour la saisir, ou consulte https://aistudio.google.com/apikey")
        return False

    ok = True
    missing = [
        (module, package)
        for module, package in (("requests", "requests"), ("edge_tts", "edge-tts"))
        if importlib.util.find_spec(module) is None
    ]
    if missing:
        print(f"[ERREUR] Dépendance(s) Python manquante(s) : {', '.join(m for m, _ in missing)}")
        if REQUIREMENTS_PATH.is_file():
            print(f'         Installe les dépendances avec : py -m pip install -r "{REQUIREMENTS_PATH}"')
        else:
            packages = " ".join(package for _, package in missing)
            print(f"         Installe-les avec : py -m pip install {packages}")
        ok = False

    if importlib.util.find_spec("openai") is None:
        print("[INFO] openai non installé : la planification LLM restera désactivée.")
        print("       Installation optionnelle : py -m pip install openai")

    try:
        check_ffmpeg()
    except RuntimeError as e:
        print(f"[ERREUR] {e}")
        ok = False

    if video_provider == "none":
        print("[INFO] Aucun fournisseur vidéo natif : le script utilisera les clips stock ou l'animation Ken Burns.")
    elif video_provider not in PROVIDER_KEYS:
        print(f"[ERREUR] Fournisseur vidéo inconnu : {video_provider}")
        ok = False
    elif not os.getenv(PROVIDER_KEYS[video_provider]):
        print(f"[ERREUR] Clé absente pour {video_provider} ({PROVIDER_KEYS[video_provider]}).")
        print("         Configure-la avec --reconfigure ou dans le fichier .env du générateur.")
        ok = False
    if not os.getenv("GEMINI_API_KEY") and not os.getenv("PEXELS_API_KEY"):
        print("[ERREUR] Aucun service d'images configuré : ajoute GEMINI_API_KEY ou PEXELS_API_KEY.")
        print("         Pour saisir une clé, relance avec --reconfigure ou utilise --image-only.")
        ok = False

    if ok:
        print("[OK] Dépendances Python, FFmpeg et configuration disponibles.")
    return ok


# ----------------------------------------------------------------------------
# 1. PLANIFICATION
# ----------------------------------------------------------------------------
PLAN_PROMPT = """Tu es un réalisateur de documentaires. À partir du sujet ci-dessous,
produis UNIQUEMENT un JSON valide (sans markdown) : une liste "scenes" de 4 à 8 scènes.
Chaque scène : "narration" (1-2 phrases percutantes, en français),
"visual" (description visuelle détaillée, en anglais),
"motion" (description du MOUVEMENT caméra/objets, en anglais — ex: "slow cinematic dolly in"),
"duration" (secondes, entier entre 5 et 12).
Respecte le style visuel demandé et assure une continuité d'éclairage, de palette
et de direction artistique entre les scènes.
Sujet : {topic}. Durée totale visée : ~{duration}s. Style visuel : {style}.
Décris un mouvement temporel crédible pour chaque scène (effet vidéo 4D).
Réponds uniquement avec le JSON."""

VISUAL_STYLES = {
    "3d": "high-end 3D render, realistic materials, dimensional lighting, detailed textures",
    "photo": "professional photorealistic photography, natural textures, accurate lighting",
    "illustration": "polished editorial illustration, coherent art direction, refined color palette",
    "cinematic": "cinematic documentary, dramatic but natural lighting, rich visual depth",
}


def _extract_json(raw: str):
    """Tolère un JSON nu ou enterré dans du markdown."""
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.startswith("json"):
            raw = raw[4:]
    s, e = raw.find("{"), raw.rfind("}")
    return json.loads(raw[s:e + 1])


def plan_scenes(topic: str, duration: int, visual_style: str = "cinematic") -> list[dict]:
    visual_style = visual_style if visual_style in VISUAL_STYLES else "cinematic"
    key = os.getenv("LLM_API_KEY")
    if key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=key,
                            base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"))
            r = client.chat.completions.create(
                model=os.getenv("LLM_MODEL", "gpt-4o-mini"),
                messages=[{"role": "user", "content":
                           PLAN_PROMPT.format(topic=topic, duration=duration,
                                              style=visual_style)}],
                temperature=0.8)
            data = _extract_json(r.choices[0].message.content)
            scenes = data["scenes"] if isinstance(data, dict) else data
            assert scenes and all("narration" in s for s in scenes)
            print(f"[LLM] {len(scenes)} scènes planifiées.")
            return scenes
        except Exception as e:
            print(f"[LLM] échec ({e}) → plan de secours.")
    n = max(3, round(duration / 10))
    tpl = [("Chaque grande histoire commence par une question.", "cinematic establishing shot", "slow push in"),
           ("Et la réponse dépasse souvent notre imagination.", "dramatic wide angle view", "gentle parallax pan"),
           ("Les détails révèlent une réalité fascinante.", "extreme close-up macro shot", "rack focus"),
           ("Chaque étape transforme notre compréhension.", "aerial drone footage style view", "sweeping aerial orbit"),
           ("Et ce n'est que le début de l'aventure.", "inspiring golden hour landscape", "slow zoom out")]
    return [{"narration": f"{topic}. {tpl[i % len(tpl)][0]}",
             "visual": f"{tpl[i % len(tpl)][1]}, {topic}, {VISUAL_STYLES[visual_style]}, 4k",
             "motion": tpl[i % len(tpl)][2],
             "duration": round(duration / n)} for i in range(n)]


# ----------------------------------------------------------------------------
# 2. VOIX OFF
# ----------------------------------------------------------------------------
async def make_voice(text: str, path: Path):
    import edge_tts
    voice = os.getenv("TTS_VOICE", "fr-FR-DeniseNeural")
    await edge_tts.Communicate(text, voice).save(str(path))


def probe_duration(path: Path) -> float:
    out = subprocess.run(["ffprobe", "-v", "quiet", "-show_entries",
                          "format=duration", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True)
    return float(out.stdout.strip() or 0)


def download(url: str, path: Path):
    import requests
    r = requests.get(url, timeout=600)
    r.raise_for_status()
    path.write_bytes(r.content)


def run(cmd: list) -> subprocess.CompletedProcess:
    """Lance ffmpeg/ffprobe et affiche la vraie erreur en cas d'échec."""
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        tail = (p.stderr or "")[-1500:]
        raise RuntimeError(f"commande échouée: {' '.join(cmd[:6])}…\n{tail}")
    return p


# ----------------------------------------------------------------------------
# 3. GÉNÉRATION VIDÉO NATIVE
# ----------------------------------------------------------------------------
def _poll(url: str, headers: dict, every=8, timeout=900) -> dict:
    import requests
    t0 = time.time()
    while time.time() - t0 < timeout:
        time.sleep(every)
        s = requests.get(url, headers=headers, timeout=30).json()
        st = s.get("status", "")
        if st in ("SUCCEEDED", "succeeded", "completed"):
            return s
        if st in ("FAILED", "failed", "canceled", "CANCELED"):
            raise RuntimeError(f"génération échouée: {s}")
        print("   … génération en cours")
    raise TimeoutError("timeout génération vidéo")


def gen_runway(image: Path, prompt: str, motion: str, out: Path):
    import requests
    key = os.environ["RUNWAY_API_KEY"]
    h = {"Authorization": f"Bearer {key}", "X-Runway-Version": "2024-11-06"}
    b64 = base64.b64encode(image.read_bytes()).decode()
    r = requests.post("https://api.dev.runwayml.com/v1/image_to_video",
                      headers=h, json={
                          "model": "gen3a_turbo",
                          "promptImage": [f"data:image/png;base64,{b64}"],
                          "promptText": f"{motion}, {prompt}",
                          "duration": 10, "ratio": "1280:720"}, timeout=60)
    r.raise_for_status()
    task = r.json()["id"]
    res = _poll(f"https://api.dev.runwayml.com/v1/tasks/{task}", h)
    download(res["output"][0], out)


def gen_luma(image: Path, prompt: str, motion: str, out: Path):
    import requests
    key = os.environ["LUMA_API_KEY"]
    h = {"Authorization": f"Bearer {key}"}
    b64 = base64.b64encode(image.read_bytes()).decode()
    r = requests.post("https://api.lumalabs.ai/dream-machine/v1/generations",
                      headers=h, json={
                          "prompt": f"{motion}, {prompt}",
                          "keyframes": {"frame0": {"type": "image", "url": f"data:image/png;base64,{b64}"}}},
                      timeout=60)
    r.raise_for_status()
    gid = r.json()["id"]
    res = _poll(f"https://api.lumalabs.ai/dream-machine/v1/generations/{gid}", h)
    download(res["assets"]["video"], out)


def gen_replicate(image: Path, prompt: str, motion: str, out: Path):
    import requests
    key = os.environ["REPLICATE_API_TOKEN"]
    model = os.getenv("REPLICATE_VIDEO_MODEL", "minimax/video-01")
    h = {"Authorization": f"Bearer {key}"}
    b64 = base64.b64encode(image.read_bytes()).decode()
    r = requests.post("https://api.replicate.com/v1/predictions",
                      headers=h, json={
                          "model": model,
                          "input": {"prompt": f"{motion}, {prompt}",
                                    "first_frame_image": f"data:image/png;base64,{b64}",
                                    "prompt_optimizer": True}}, timeout=60)
    r.raise_for_status()
    res = _poll(r.json()["urls"]["get"], h)
    u = res["output"]
    download(u[0] if isinstance(u, list) else u, out)


VIDEO_PROVIDERS = {"runway": gen_runway, "luma": gen_luma, "replicate": gen_replicate}


# ----------------------------------------------------------------------------
# 4. VISUELS
# ----------------------------------------------------------------------------
def fetch_ai_image(prompt: str, path: Path, w=1920, h=1080,
                   visual_style: str = "cinematic"):
    import urllib.error
    import urllib.request

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "clé GEMINI_API_KEY absente : crée une clé dans Google AI Studio, "
            "puis configure-la avec --reconfigure ou dans le fichier .env du générateur"
        )

    style = VISUAL_STYLES.get(visual_style, VISUAL_STYLES["cinematic"])
    ratio = f"{w}:{h}"
    detailed_prompt = (
        f"Create one original image. {style}. "
        f"Use a clear composition suitable for a {ratio} aspect ratio. "
        f"User request: {prompt}"
    )
    payload = json.dumps({
        "model": "gemini-nano-banana-2.1",
        "input": [{"type": "text", "text": detailed_prompt}],
    }).encode("utf-8")
    request = urllib.request.Request(
        "https://generativelanguage.googleapis.com/v1beta/interactions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": api_key,
            "Api-Revision": "2026-05-20",
            "User-Agent": "AI-Video-Generator/2.4",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            raw_response = response.read(32 * 1024 * 1024 + 1)
            if len(raw_response) > 32 * 1024 * 1024:
                raise RuntimeError("la réponse Gemini dépasse la limite de 32 Mo")
            data = json.loads(raw_response)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            message = "clé Gemini invalide ou accès au modèle non autorisé"
        elif e.code == 429:
            message = "quota Gemini atteint; vérifie les limites et la facturation de ton compte"
        else:
            message = f"Gemini a refusé la génération (HTTP {e.code})"
        raise RuntimeError(message) from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"service Gemini inaccessible : {e}") from e
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise RuntimeError("Gemini a renvoyé une réponse JSON invalide") from e

    if not isinstance(data, dict):
        raise RuntimeError("Gemini a renvoyé une réponse invalide")
    image = data.get("output_image")
    if not isinstance(image, dict):
        image = next(
            (item for item in data.get("outputs", [])
             if isinstance(item, dict) and item.get("type") == "image"),
            None,
        )
    encoded = image.get("data") if isinstance(image, dict) else None
    mime_type = image.get("mime_type", "image/png") if isinstance(image, dict) else ""
    if not isinstance(encoded, str) or not encoded:
        raise RuntimeError("Gemini n'a renvoyé aucune image; essaie une autre description")
    if encoded.startswith("data:") and "," in encoded:
        header, encoded = encoded.split(",", 1)
        mime_type = header[5:].split(";", 1)[0].lower() or mime_type
    if len(encoded) > 28 * 1024 * 1024:
        raise RuntimeError("l'image renvoyée dépasse la limite de 20 Mo")

    try:
        content = base64.b64decode(encoded, validate=True)
    except (ValueError, base64.binascii.Error) as e:
        raise RuntimeError("Gemini a renvoyé des données d'image invalides") from e
    if not content or len(content) > 20 * 1024 * 1024:
        raise RuntimeError("taille d'image invalide ou supérieure à 20 Mo")

    signatures = {
        "image/png": (b"\x89PNG\r\n\x1a\n", ".png"),
        "image/jpeg": (b"\xff\xd8\xff", ".jpg"),
    }
    valid_signature = (
        mime_type in signatures and content.startswith(signatures[mime_type][0])
    ) or (mime_type == "image/webp" and content.startswith(b"RIFF") and content[8:12] == b"WEBP")
    if not valid_signature:
        raise RuntimeError("Gemini a renvoyé un format d'image non pris en charge")

    extension = signatures[mime_type][1] if mime_type in signatures else ".webp"
    output = path.with_suffix(extension)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(content)
    return output


def setup_image_credentials():
    cfg = _load_env()
    key = _ask(
        "Clé API Gemini pour générer les images (Google AI Studio)",
        cfg.get("GEMINI_API_KEY", ""),
        secret=True,
    )
    if not key:
        raise RuntimeError(
            "une clé Gemini est requise pour générer une image. "
            "Crée-la sur https://aistudio.google.com/apikey"
        )
    cfg["GEMINI_API_KEY"] = key
    _save_env(cfg)
    os.environ["GEMINI_API_KEY"] = key


def fetch_pexels_clip(prompt: str, path: Path) -> bool:
    key = os.getenv("PEXELS_API_KEY")
    if not key:
        return False
    import requests
    r = requests.get("https://api.pexels.com/videos/search",
                     headers={"Authorization": key},
                     params={"query": prompt, "per_page": 5}, timeout=30)
    vids = r.json().get("videos", [])
    if not vids:
        return False
    files = sorted(vids[0]["video_files"], key=lambda f: f.get("width", 0))
    f = next((f for f in files if f.get("width", 0) >= 1280), files[-1])
    download(f["link"], path)
    return True


def normalize_clip(src: Path, dur: float, out: Path, fade: float):
    """Normalise : 1080p25, yuv420p, fondu entrant/sortant (le param 'fade'
    était déclaré mais jamais utilisé en v2 → corrigé ici)."""
    fade = min(fade, dur / 2 - 0.1)
    fades = (f"fade=t=in:st=0:d={fade},fade=t=out:st={dur - fade:.3f}:d={fade}"
             if fade > 0 else "")
    vf = ("scale=1920:1080:force_original_aspect_ratio=decrease,"
          "pad=1920:1080:(ow-iw)/2:(oh-ih)/2,fps=25,format=yuv420p"
          + ("," + fades if fades else ""))
    run(["ffmpeg", "-y", "-i", str(src), "-t", str(dur),
         "-vf", vf, "-an",
         "-c:v", "libx264", "-preset", "fast", "-crf", "20", str(out)])


def build_kenburns_clip(img: Path, dur: float, out: Path, idx: int):
    """BUG CRITIQUE v2 : la chaîne zoom contenait littéralement '({d}*25)'
    (jamais formatée) → ffmpeg rejetait l'expression et TOUT le repli Ken
    Burns échouait. Corrigé : frames est calculé en Python."""
    frames = max(1, int(dur * 25))
    direction = -1 if idx % 2 else 1          # alterne zoom-in / zoom-out
    if direction == 1:
        zexpr = f"min(1.0+0.35*on/{frames},1.35)"
    else:
        zexpr = f"max(1.35-0.35*on/{frames},1.0)"
    vf = (f"scale=2560:1440:force_original_aspect_ratio=increase,crop=2560:1440,"
          f"zoompan=z='{zexpr}':x='iw/2-(iw/zoom/2)+{idx*7}*sin(on/60)':"
          f"y='ih/2-(ih/zoom/2)':d=1:s=1920x1080:fps=25,format=yuv420p")
    # d=1 : zoompan reçoit déjà 25 images/s grâce à -loop 1 ; d={frames} duplique
    run(["ffmpeg", "-y", "-loop", "1", "-framerate", "25", "-i", str(img),
         "-vf", vf, "-t", str(dur),
         "-c:v", "libx264", "-preset", "fast", "-crf", "20", "-an", str(out)])


# ----------------------------------------------------------------------------
# 5. ASSEMBLAGE
# ----------------------------------------------------------------------------
def build_subtitles(scenes, timings, srt: Path):
    def fmt(t):
        h, m, s = int(t // 3600), int(t % 3600 // 60), t % 60
        return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".", ",")
    lines = []
    for i, (sc, (start, end)) in enumerate(zip(scenes, timings), 1):
        lines += [str(i), f"{fmt(start)} --> {fmt(end)}", sc["narration"], ""]
    srt.write_text("\n".join(lines), encoding="utf-8")


def assemble(clips: list[Path], voices: list[Path], srt: Path,
             music: str | None, out: Path, transition: float):
    n = len(clips)
    t = min(transition, 0.5) if n == 1 else transition
    durs = [probe_duration(c) for c in clips]

    # concat voix — réencodée en WAV : '-c copy' sur des mp3 crée des clics
    # aux jointures et des décalages de durée.
    vlist = WORKDIR / "voices.txt"
    vlist.write_text("".join(f"file '{v.resolve()}'\n" for v in voices))
    voice = WORKDIR / "voice.wav"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(vlist),
         "-c:a", "pcm_s16le", str(voice)])

    inputs = []
    for c in clips:
        inputs += ["-i", str(c)]
    vidx = n
    inputs += ["-i", str(voice)]

    prev, offset = "[0:v]", 0.0
    parts = []
    for i in range(1, n):
        offset += durs[i - 1] - t
        if offset < 0:
            raise RuntimeError(f"plan {i} trop court pour la transition ({t}s)")
        label = f"[xv{i}]" if i < n - 1 else "[vx]"
        parts.append(f"{prev}[{i}:v]xfade=transition=fade:duration={t}:offset={offset:.3f}{label}")
        prev = label
    vchain = ";".join(parts) + ";" if parts else ""

    v_in = f"[{vidx}:a]loudnorm[a]"
    if music:
        midx = n + 1
        inputs += ["-i", music]
        v_in += f";[{midx}:a]volume=-14dB[m];[a][m]amix=inputs=2:duration=first[aout]"
        aout = "[aout]"
    else:
        aout = "[a]"

    total = sum(durs) - t * (n - 1)
    fade_out_st = max(total - t, 0)
    sub = str(srt.resolve()).replace(":", "\\:")   # échappe ':' (paths Windows)
    vfc = (vchain + f"[vx]fade=t=in:st=0:d={t},fade=t=out:st={fade_out_st:.3f}:d={t},"
           f"subtitles='{sub}':force_style='FontSize=22,OutlineColour=&H80000000'[vout]")
    fcomp = (f"{vfc};{v_in}" if n > 1 else
             f"[0:v]fade=t=in:st=0:d={t},fade=t=out:st={fade_out_st:.3f}:d={t},"
             f"subtitles='{sub}':force_style='FontSize=22,OutlineColour=&H80000000'[vout];{v_in}")

    run(["ffmpeg", "-y", *inputs, "-filter_complex", fcomp,
         "-map", "[vout]", "-map", aout,
         "-c:v", "libx264", "-preset", "medium", "-crf", "19",
         "-c:a", "aac", "-b:a", "192k", "-shortest", str(out)])
    print(f"\n✅ Vidéo générée : {out.resolve()} ({total:.0f}s)")


# ----------------------------------------------------------------------------
# 0. CONFIGURATION INTERACTIVE — demande les paramètres de connexion avant usage
# ----------------------------------------------------------------------------
ENV_PATH = Path(__file__).resolve().parent / ".env"


def _load_env():
    """Lit le .env local s'il existe (sans dépendance externe)."""
    if not ENV_PATH.exists():
        return {}
    cfg = {}
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            cfg[k.strip()] = v.strip()
    return cfg


def _save_env(cfg: dict):
    lines = [f"{k}={v}" for k, v in cfg.items() if v]
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:  # permissions restrictives sur le fichier de secrets
        os.chmod(ENV_PATH, 0o600)
    except OSError:
        pass


def _ask(prompt: str, default: str = "", secret: bool = False) -> str:
    from getpass import getpass
    hint = "[•••••••• (conservée si vide)]" if (secret and default) else            (f" [{default}]" if default else "")
    label = f"{prompt} {hint} : "
    while True:
        try:
            val = getpass(label) if secret else input(label)
        except (EOFError, KeyboardInterrupt):
            sys.exit("\n[CONFIG] Interrompu par l'utilisateur.")
        val = val.strip() or default
        return val


def setup_credentials(force: bool = False) -> dict:
    """Pose les questions de connexion AVANT toute utilisation, puis injecte
    les valeurs dans os.environ. Réutilise le .env existant sauf si force."""
    cfg = {} if force else _load_env()
    new = {}

    print("═" * 62)
    print("  CONFIGURATION — paramètres de connexion (entrée masquée pour les clés)")
    print("═" * 62)

    # --- Identité de l'utilisateur ---
    new["USER_EMAIL"] = _ask(
        "Adresse e-mail (identifiant / traçabilité des générations)",
        cfg.get("USER_EMAIL", ""))

    # --- LLM (planification des scènes) ---
    print("\n── Planification (LLM) ──")
    new["LLM_BASE_URL"] = _ask(
        "URL de l'API LLM", cfg.get("LLM_BASE_URL", "https://api.openai.com/v1"))
    new["LLM_MODEL"] = _ask(
        "Modèle LLM", cfg.get("LLM_MODEL", "gpt-4o-mini"))
    new["LLM_API_KEY"] = _ask(
        "Clé API LLM", cfg.get("LLM_API_KEY", ""), secret=True)
    if not new["LLM_API_KEY"]:
        print("   ⚠ aucune clé LLM → plan de secours générique utilisé.")

    # --- Voix off ---
    print("\n── Voix off (edge-tts) ──")
    new["TTS_VOICE"] = _ask(
        "Voix (ex: fr-FR-DeniseNeural, fr-FR-HenriNeural, "
        "en-US-AriaNeural)",
        cfg.get("TTS_VOICE", "fr-FR-DeniseNeural"))

    # --- Génération d'images ---
    print("\n── Génération d'images (Gemini) ──")
    new["GEMINI_API_KEY"] = _ask(
        "Clé API Gemini (Google AI Studio, vide = image IA désactivée)",
        cfg.get("GEMINI_API_KEY", ""),
        secret=True)
    if not new["GEMINI_API_KEY"]:
        print("   ⚠ aucune clé Gemini → configure une clé ou ajoute PEXELS_API_KEY pour les visuels.")

    # --- Provider vidéo natif ---
    print("\n── Vidéo native (optionnel : 'none' pour Ken Burns / stock) ──")
    choice = _ask("Provider (none|runway|luma|replicate)",
                  cfg.get("VIDEO_PROVIDER", "none")).lower()
    if choice not in ("none", "runway", "luma", "replicate"):
        print(f"   ⚠ '{choice}' inconnu → 'none'.")
        choice = "none"
    new["VIDEO_PROVIDER"] = choice
    keyvar = {"runway": "RUNWAY_API_KEY", "luma": "LUMA_API_KEY",
              "replicate": "REPLICATE_API_TOKEN"}.get(choice)
    if keyvar:
        new[keyvar] = _ask(f"Clé API {choice}", cfg.get(keyvar, ""), secret=True)
        if choice == "replicate":
            new["REPLICATE_VIDEO_MODEL"] = _ask(
                "Modèle vidéo Replicate",
                cfg.get("REPLICATE_VIDEO_MODEL", "minimax/video-01"))

    # --- Stock Pexels ---
    print("\n── Clips stock Pexels (optionnel) ──")
    new["PEXELS_API_KEY"] = _ask(
        "Clé API Pexels (vide = désactivé)", cfg.get("PEXELS_API_KEY", ""),
        secret=True)

    cfg.update({k: v for k, v in new.items() if v})
    _save_env(cfg)
    os.environ.update(cfg)   # le reste du script lit os.getenv directement

    # --- Validation rapide du LLM ---
    if cfg.get("LLM_API_KEY"):
        try:
            from openai import OpenAI
            OpenAI(api_key=cfg["LLM_API_KEY"],
                   base_url=cfg.get("LLM_BASE_URL")).models.list()
            print("✅ Connexion LLM vérifiée.")
        except Exception as e:
            print(f"⚠ LLM injoignable ({e}) — la génération utilisera le plan de secours.")
    print("═" * 62 + "\n")
    return cfg



# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------
async def main():
    ap = argparse.ArgumentParser(description="Générateur de vidéos IA")
    ap.add_argument("prompt", nargs="?")
    ap.add_argument("--duration", type=int, default=60)
    ap.add_argument("--music", help="fichier musique de fond (optionnel)")
    ap.add_argument("--out", help="chemin du fichier de sortie")
    ap.add_argument("--image-only", action="store_true",
                    help="génère une image sans FFmpeg (clé Gemini requise)")
    ap.add_argument("--visual-style", choices=list(VISUAL_STYLES), default="cinematic",
                    help="direction artistique des images et scènes")
    ap.add_argument("--video-provider", choices=["auto", "none"] + list(VIDEO_PROVIDERS),
                    default="auto",
                    help="'auto' = valeur du .env / configuration interactive")
    ap.add_argument("--reconfigure", action="store_true",
                    help="repose toutes les questions de connexion")
    ap.add_argument("--no-config", action="store_true",
                    help="ignore la configuration interactive (CI/scripts)")
    ap.add_argument("--transition", type=float, default=0.8)
    ap.add_argument("--check", action="store_true",
                    help="vérifie les dépendances, FFmpeg et la configuration sans générer")
    a = ap.parse_args()

    if a.check:
        os.environ.update(_load_env())
        provider = a.video_provider
        if provider == "auto":
            provider = os.getenv("VIDEO_PROVIDER", "none")
        if not check_dependencies(provider, image_only=a.image_only):
            sys.exit(1)
        return
    if not a.prompt:
        ap.error("le sujet est requis (sauf avec --check)")

    if a.image_only:
        os.environ.update(_load_env())
        if not os.getenv("GEMINI_API_KEY"):
            if a.no_config:
                ap.error("--no-config exige GEMINI_API_KEY dans l'environnement ou le fichier .env")
            try:
                setup_image_credentials()
            except RuntimeError as e:
                ap.error(str(e))
        target = Path(a.out) if a.out else OUTDIR / "image_ia.png"
        try:
            image = fetch_ai_image(a.prompt, target, 1024, 1024, a.visual_style)
        except RuntimeError as e:
            print(f"[ERREUR] {e}", file=sys.stderr)
            sys.exit(1)
        print(f"\n✅ Image générée : {image.resolve()}")
        return

    # Paramètres de connexion AVANT tout traitement
    if a.no_config:
        os.environ.update(_load_env())          # .env silencieux si présent
    elif a.reconfigure or not _load_env():
        setup_credentials(force=a.reconfigure)
    else:
        os.environ.update(_load_env())
        print(f"[CONFIG] Connexion chargée depuis {ENV_PATH} "
              f"(utilisateur: {os.getenv('USER_EMAIL', '?')}) — "
              f"--reconfigure pour modifier.\n")
    if a.video_provider == "auto":
        a.video_provider = os.getenv("VIDEO_PROVIDER", "none")

    if not check_dependencies(a.video_provider):
        sys.exit(1)
    for d in ("clips", "img", "voice"):
        (WORKDIR / d).mkdir(parents=True, exist_ok=True)
    OUTDIR.mkdir(exist_ok=True)

    if not os.getenv("LLM_API_KEY") and not a.no_config:
        print("[INFO] LLM non configuré → narration générique (plan de secours).")
    scenes = plan_scenes(a.prompt, a.duration, a.visual_style)
    provider = VIDEO_PROVIDERS.get(a.video_provider)

    clips, voices, timings = [], [], []
    t = 0.0
    for i, sc in enumerate(scenes):
        print(f"[{i+1}/{len(scenes)}] {sc['narration'][:60]}...")
        v = WORKDIR / "voice" / f"sc{i}.mp3"
        await make_voice(sc["narration"], v)
        dur = max(4.0, probe_duration(v))
        clip = WORKDIR / "clips" / f"sc{i}.mp4"
        img = WORKDIR / "img" / f"sc{i}.png"
        done = False

        if provider and (img.exists() or fetch_ai_image(sc["visual"], img, visual_style=a.visual_style)):
            try:
                raw = WORKDIR / "clips" / f"raw{i}.mp4"
                print(f"   → vidéo native ({a.video_provider})…")
                provider(img, sc["visual"], sc.get("motion", "cinematic camera move"), raw)
                normalize_clip(raw, dur, clip, a.transition)
                done = True
            except Exception as e:
                print(f"   ⚠ vidéo native échouée ({e}) → repli Ken Burns")

        if not done:
            stock = WORKDIR / "clips" / f"stock{i}.mp4"
            if fetch_pexels_clip(sc["visual"], stock):
                normalize_clip(stock, dur, clip, a.transition)
            else:
                if not img.exists():
                    fetch_ai_image(sc["visual"], img, visual_style=a.visual_style)
                build_kenburns_clip(img, dur, clip, i)

        # FIX : les timings des sous-titres doivent tenir compte du recouvrement
        # xfade, sinon ils dérivent d'une transition à chaque plan.
        clips.append(clip); voices.append(v); timings.append((t, t + dur))
        t += dur - a.transition

    srt = WORKDIR / "subs.srt"
    build_subtitles(scenes, timings, srt)
    output = Path(a.out) if a.out else Path("video_ia.mp4")
    output.parent.mkdir(parents=True, exist_ok=True)
    assemble(clips, voices, srt, a.music, output, a.transition)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

# ────────────────────────────────────────────────────────────────────────────
# CHANGELOG v2 → v2.4
# 1. CRITIQUE — Ken Burns : "({d}*25)" jamais formaté → expression ffmpeg
#    invalide, tout le repli échouait. Remplacé par d=1 + -loop 1 -framerate 25,
#    alternance zoom-in/zoom-out par plan.
# 2. CRITIQUE — Sous-titres : dérive de timing (la somme ne soustrayait pas
#    les recouvrements xfade). Corrigé : t += dur - transition.
# 3. normalize_clip : le paramètre 'fade' était ignoré → fondu entrant/sortant
#    par plan réellement appliqués.
# 4. Concat voix : '-c copy' sur mp3 → clics/décalages ; remplacé par
#    réencodage WAV avant loudnorm.
# 5. Robustesse : check_ffmpeg() au démarrage ; run() affiche le vrai stderr
#    FFmpeg ; échappement ':' du chemin SRT ; offset xfade négatif détecté ;
#    _poll: paramètre 'ok' fantôme supprimé ; parsing JSON LLM tolérant au
#    markdown ; quote(safe='') pour Pollinations ; scène unique gérée.
# 6. Direction artistique : --visual-style applique un style cohérent (3D,
#    photo, illustration ou cinéma) au plan et à chaque image générée.
# 7. Images : génération Gemini avec clé gardée côté local, réponse image
#    validée et écrite selon son véritable format.
# 8. Démarrage : --check et validation préalable des modules Python, FFmpeg,
#    FFprobe et de la clé API du fournisseur vidéo choisi.
# 9. Diagnostic : les dépendances manquantes affichent leurs commandes
#    d'installation ; aucun paquet n'est installé automatiquement.
# 10. Mode --image-only : génération Gemini sans FFmpeg ni dépendances Python
#     externes; une clé API Gemini est requise et saisie sans affichage.
# 11. Sortie : extension choisie selon le type MIME réel (JPEG/PNG/WebP),
#     création automatique du dossier parent et limite de 20 Mo.
# ────────────────────────────────────────────────────────────────────────────
